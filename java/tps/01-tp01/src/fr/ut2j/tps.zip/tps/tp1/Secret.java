package fr.ut2j.tps.tp1;
/*
 * Université Toulouse 2 Jean Jaures
 * L3 MIASHS 2021-2022
 * BERRANI Dahbia
 * berrani.dehbia1993@gmail.com
 */

public class Secret {


    public static void main(String [] args){
//        int nombreSecre;
//        int nmUtilisateur;
//        int compteur;
//        public static final int nombreEssaie;
//
//        static{
//            nombreEssaie = 5;
//        }
//        int reponse=1;
//        for(reponse ==1){
//           int compteur = 0;
//           int nombreSucre = Math.random();
//
//        }
   }
}
