package fr.ut2j.tps;
/*
 * Université Toulouse 2 Jean Jaures
 * L3 MIASHS 2021-2022
 * BERRANI Dahbia
 * berrani.dehbia1993@gmail.com
 */

import fr.ut2j.tps.tp3.Entree;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class testEntree {
    @Test
    public  void testEquals(){
        Entree entree = new Entree(5,null);
        Entree entree1 = new Entree(5,null);
        assertEquals(entree,entree1);

    }
}
