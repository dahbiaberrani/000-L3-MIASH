package observers;

import observable.Observable;

public interface Observer {
    void update(int etat);
    //void update(Observable observable);
}
