public class StrategyImpl3 implements IStrategy {
    @Override
    public void appliquer() {
        System.out.println("J'applique la stratégie 3");
    }
}
