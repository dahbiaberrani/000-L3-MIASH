public class StrategieImp1 implements RouteStrategy{
    @Override
    public void applique() {

    }
}
