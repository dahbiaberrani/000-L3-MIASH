public interface RouteStrategy {
    public void applique();

}
