public class StrategieImpl3 implements RouteStrategy{

    @Override
    public void applique() {

    }
}
