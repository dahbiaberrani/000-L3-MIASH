public class StrategieImp2 implements RouteStrategy{

    @Override
    public void applique() {

    }
}
