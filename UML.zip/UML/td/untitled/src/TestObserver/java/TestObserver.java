public class TestObserver {
    public static void main(String[] args) {
        ObserverImpl Obser
    }
}
