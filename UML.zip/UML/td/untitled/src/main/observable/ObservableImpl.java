import java.util.ArrayList;

public class ObservableImpl implements Observable{
    private Etat
    private Liste<Observable> observer = new ArrayList<>();
}
