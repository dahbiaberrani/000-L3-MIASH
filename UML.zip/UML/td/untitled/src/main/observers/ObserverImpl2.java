public class ObserverImpl2 {
}
