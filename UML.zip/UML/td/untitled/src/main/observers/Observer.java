public interface Observer {


    public interface update() {

    }
}
