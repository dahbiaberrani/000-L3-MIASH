public class ObserverImpl1 implements Observer {



}
