


public class App {
    public static void main(String[] args) {
        Connection c1 = SConnection.getConnection();
        Connection c2 = SConnection.getConnection();
        Connection c3 = SConnection.getConnection();
    }

}
