public class Connection {

    public Connection(){
        System.out.println("Création d'une connection");
    }

}
