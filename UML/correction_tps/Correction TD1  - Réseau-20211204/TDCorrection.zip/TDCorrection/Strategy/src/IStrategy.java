public interface IStrategy {
    public void appliquer();
}
