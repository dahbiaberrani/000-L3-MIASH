class Reseau:

    connecter():
    
