class Noued:
    def create(self,adress,noued_suivant):
        


    