#pragma once
#include <cstddef>
size_t strlen_(const char *str);
void strcpy_(char *destination, const char *source);
char* strncpy_(char *destination, const char *source,size_t num);

